# zcool-fullpage
站酷全屏滚动网站展示V1.0

##这个demo用jquery的fullpage插件实现了css3的一些动画和滚屏效果,用到了以下方法:
 + jquery:jquery.fullPage
 + css:transform transition-delay 延时触发  rotate 旋转 keyframes 动画 animation
 
##本项目属于业余爱好练手,文件中包含完整js文件和pic文件,感兴趣的同学可以down下来进行练习,不必署名.
